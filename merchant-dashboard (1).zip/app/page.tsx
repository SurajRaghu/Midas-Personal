"use client"

import { useState } from "react"
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { RefreshCw, Download } from "lucide-react"
import { AppSidebar } from "@/components/app-sidebar"
import { MainDashboard } from "@/components/main-dashboard"
import { ErrorDashboard } from "@/components/error-dashboard"

export default function MerchantDashboard() {
  const [activeView, setActiveView] = useState("dashboard")

  const handleNavigation = (view: string) => {
    setActiveView(view)
  }

  const getPageTitle = () => {
    switch (activeView) {
      case "dashboard":
        return "Merchant Dashboard"
      case "errors":
        return "Error Dashboard"
      case "settings":
        return "Settings"
      default:
        return "Merchant Dashboard"
    }
  }

  const renderContent = () => {
    switch (activeView) {
      case "dashboard":
        return <MainDashboard />
      case "errors":
        return <ErrorDashboard />
      case "settings":
        return (
          <div className="flex items-center justify-center h-64">
            <p className="text-muted-foreground">Settings page coming soon...</p>
          </div>
        )
      default:
        return <MainDashboard />
    }
  }

  return (
    <SidebarProvider>
      <AppSidebar activeItem={activeView} onNavigate={handleNavigation} />
      <div className="flex-1 flex flex-col min-h-screen">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold">{getPageTitle()}</h1>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </header>
        <main className="flex-1 p-6">{renderContent()}</main>
      </div>
    </SidebarProvider>
  )
}
