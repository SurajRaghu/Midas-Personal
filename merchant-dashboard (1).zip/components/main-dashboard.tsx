"use client"

import { useState } from "react"
import { CalendarDays, Search, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Mock data for Earn transactions
const earnData = [
  {
    date: "2024-01-15",
    fee: 2.5,
    mintingDate: "2024-01-16",
    app: "ShopApp",
    refId: "REF001",
    cancelledCoins: 0,
    earnedCoins: 100,
    readyToMintCoins: 95,
    mintedCoins: 95,
  },
  {
    date: "2024-01-14",
    fee: 1.75,
    mintingDate: "2024-01-15",
    app: "FoodDelivery",
    refId: "REF002",
    cancelledCoins: 5,
    earnedCoins: 75,
    readyToMintCoins: 70,
    mintedCoins: 70,
  },
  {
    date: "2024-01-13",
    fee: 3.2,
    mintingDate: "2024-01-14",
    app: "RideShare",
    refId: "REF003",
    cancelledCoins: 0,
    earnedCoins: 150,
    readyToMintCoins: 150,
    mintedCoins: 150,
  },
  {
    date: "2024-01-12",
    fee: 0.9,
    mintingDate: "2024-01-13",
    app: "ShopApp",
    refId: "REF004",
    cancelledCoins: 10,
    earnedCoins: 45,
    readyToMintCoins: 35,
    mintedCoins: 35,
  },
]

// Mock data for Redeem transactions
const redeemData = [
  {
    id: "TXN001",
    refId: "REF001",
    date: "2024-01-15",
    settlementDate: "2024-01-17",
    transactionType: "Cashback",
    blockedCoins: 0,
    unblockedCoins: 95,
    redeemedCoins: 95,
    fee: 2.5,
    settledAmount: 92.5,
    settlementStatus: "Completed",
  },
  {
    id: "TXN002",
    refId: "REF002",
    date: "2024-01-14",
    settlementDate: "2024-01-16",
    transactionType: "Reward",
    blockedCoins: 5,
    unblockedCoins: 65,
    redeemedCoins: 70,
    fee: 1.75,
    settledAmount: 68.25,
    settlementStatus: "Completed",
  },
  {
    id: "TXN003",
    refId: "REF003",
    date: "2024-01-13",
    settlementDate: "2024-01-15",
    transactionType: "Cashback",
    blockedCoins: 0,
    unblockedCoins: 150,
    redeemedCoins: 150,
    fee: 3.2,
    settledAmount: 146.8,
    settlementStatus: "Completed",
  },
  {
    id: "TXN004",
    refId: "REF004",
    date: "2024-01-12",
    settlementDate: "Pending",
    transactionType: "Reward",
    blockedCoins: 10,
    unblockedCoins: 25,
    redeemedCoins: 35,
    fee: 0.9,
    settledAmount: 34.1,
    settlementStatus: "Pending",
  },
]

export function MainDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [dateFilter, setDateFilter] = useState("2024-01-15")
  const [appFilter, setAppFilter] = useState("ShopApp")
  const [transactionIdFilter, setTransactionIdFilter] = useState("TXN001")

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case "Pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const filteredEarnData = earnData.filter((item) => {
    const matchesSearch =
      searchTerm === "" ||
      item.refId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.app.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesApp = appFilter === "" || item.app === appFilter
    const matchesDate = dateFilter === "" || item.date.includes(dateFilter)
    const matchesTransactionId = transactionIdFilter === "" || item.refId.includes(transactionIdFilter)

    return matchesSearch && matchesApp && matchesDate && matchesTransactionId
  })

  const filteredRedeemData = redeemData.filter((item) => {
    const matchesSearch =
      searchTerm === "" ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.refId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.transactionType.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDate = dateFilter === "" || item.date.includes(dateFilter)
    const matchesTransactionId =
      transactionIdFilter === "" || item.id.includes(transactionIdFilter) || item.refId.includes(transactionIdFilter)

    return matchesSearch && matchesDate && matchesTransactionId
  })

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earned</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">370 coins</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Redeemed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">350 coins</div>
            <p className="text-xs text-muted-foreground">+8% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Settlement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$34.10</div>
            <p className="text-xs text-muted-foreground">1 transaction</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Fees</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$8.35</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-1 items-center space-x-2">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Select value={dateFilter} onValueChange={setDateFilter}>
            <SelectTrigger className="w-[140px]">
              <CalendarDays className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Date" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024-01-15">2024-01-15</SelectItem>
              <SelectItem value="2024-01-14">2024-01-14</SelectItem>
              <SelectItem value="2024-01-13">2024-01-13</SelectItem>
              <SelectItem value="2024-01-12">2024-01-12</SelectItem>
            </SelectContent>
          </Select>
          <Select value={appFilter} onValueChange={setAppFilter}>
            <SelectTrigger className="w-[140px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="App" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ShopApp">ShopApp</SelectItem>
              <SelectItem value="FoodDelivery">FoodDelivery</SelectItem>
              <SelectItem value="RideShare">RideShare</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Transaction ID"
            value={transactionIdFilter}
            onChange={(e) => setTransactionIdFilter(e.target.value)}
            className="w-[140px]"
          />
        </div>
      </div>

      {/* Tabs for Earn and Redeem */}
      <Tabs defaultValue="earn" className="space-y-4">
        <TabsList>
          <TabsTrigger value="earn">Earn</TabsTrigger>
          <TabsTrigger value="redeem">Redeem</TabsTrigger>
        </TabsList>

        <TabsContent value="earn" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Earn Transactions</CardTitle>
              <CardDescription>Track your earning transactions and coin minting status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Fee</TableHead>
                      <TableHead>Minting Date</TableHead>
                      <TableHead>App</TableHead>
                      <TableHead>Ref ID</TableHead>
                      <TableHead>Cancelled Coins</TableHead>
                      <TableHead>Earned Coins</TableHead>
                      <TableHead>Ready to Mint</TableHead>
                      <TableHead>Minted Coins</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEarnData.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>{item.date}</TableCell>
                        <TableCell>${item.fee.toFixed(2)}</TableCell>
                        <TableCell>{item.mintingDate}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.app}</Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{item.refId}</TableCell>
                        <TableCell className="text-red-600">{item.cancelledCoins}</TableCell>
                        <TableCell className="text-green-600 font-medium">{item.earnedCoins}</TableCell>
                        <TableCell className="text-blue-600">{item.readyToMintCoins}</TableCell>
                        <TableCell className="text-purple-600 font-medium">{item.mintedCoins}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="redeem" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Redeem Transactions</CardTitle>
              <CardDescription>Monitor your redemption transactions and settlement status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Ref ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Settlement Date</TableHead>
                      <TableHead>Transaction Type</TableHead>
                      <TableHead>Blocked Coins</TableHead>
                      <TableHead>Unblocked Coins</TableHead>
                      <TableHead>Redeemed Coins</TableHead>
                      <TableHead>Fee</TableHead>
                      <TableHead>Settled Amount</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRedeemData.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-mono text-sm">{item.id}</TableCell>
                        <TableCell className="font-mono text-sm">{item.refId}</TableCell>
                        <TableCell>{item.date}</TableCell>
                        <TableCell>{item.settlementDate}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.transactionType}</Badge>
                        </TableCell>
                        <TableCell className="text-red-600">{item.blockedCoins}</TableCell>
                        <TableCell className="text-green-600">{item.unblockedCoins}</TableCell>
                        <TableCell className="text-blue-600 font-medium">{item.redeemedCoins}</TableCell>
                        <TableCell>${item.fee.toFixed(2)}</TableCell>
                        <TableCell className="font-medium">${item.settledAmount.toFixed(2)}</TableCell>
                        <TableCell>{getStatusBadge(item.settlementStatus)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
