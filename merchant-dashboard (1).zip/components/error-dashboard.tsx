"use client"

import { useState } from "react"
import { AlertTriangle, Download, Mail, Search, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

// Mock error data
const errorData = [
  {
    date: "2024-01-15",
    merchant: "ShopApp",
    errorCode: "API_TIMEOUT",
    errorCategory: "Network",
    severity: "High",
    errorCount: 45,
    deviceType: "Mobile",
    sdkVersion: "2.1.0",
    osType: "Android",
    errorMessage: "Request timeout after 30 seconds",
    description: "API request exceeded the maximum timeout limit of 30 seconds",
  },
  {
    date: "2024-01-15",
    merchant: "FoodDelivery",
    errorCode: "INVALID_TOKEN",
    errorCategory: "Authentication",
    severity: "Critical",
    errorCount: 23,
    deviceType: "Mobile",
    sdkVersion: "2.0.5",
    osType: "iOS",
    errorMessage: "Authentication token is invalid or expired",
    description: "The provided authentication token is either malformed, expired, or revoked",
  },
  {
    date: "2024-01-14",
    merchant: "RideShare",
    errorCode: "RATE_LIMIT_EXCEEDED",
    errorCategory: "Rate Limiting",
    severity: "Medium",
    errorCount: 67,
    deviceType: "Web",
    sdkVersion: "1.9.2",
    osType: "Web",
    errorMessage: "Rate limit exceeded for API endpoint",
    description: "The number of requests has exceeded the allowed rate limit for this endpoint",
  },
  {
    date: "2024-01-14",
    merchant: "ShopApp",
    errorCode: "DATABASE_CONNECTION",
    errorCategory: "Database",
    severity: "Critical",
    errorCount: 12,
    deviceType: "Mobile",
    sdkVersion: "2.1.0",
    osType: "Android",
    errorMessage: "Failed to establish database connection",
    description: "Unable to connect to the primary database server",
  },
  {
    date: "2024-01-13",
    merchant: "FoodDelivery",
    errorCode: "VALIDATION_ERROR",
    errorCategory: "Validation",
    severity: "Low",
    errorCount: 89,
    deviceType: "Mobile",
    sdkVersion: "2.0.5",
    osType: "iOS",
    errorMessage: "Request validation failed",
    description: "One or more required fields are missing or contain invalid data",
  },
]

interface ErrorDashboardProps {
  className?: string
}

export function ErrorDashboard({ className }: ErrorDashboardProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [dateFilter, setDateFilter] = useState("2024-01-15")
  const [merchantFilter, setMerchantFilter] = useState("ShopApp")
  const [severityFilter, setSeverityFilter] = useState("Critical")
  const [deviceFilter, setDeviceFilter] = useState("Mobile")
  const [sdkVersionFilter, setSdkVersionFilter] = useState("2.1.0")
  const [osFilter, setOsFilter] = useState("Android")
  const [errorCodeFilter, setErrorCodeFilter] = useState("API_TIMEOUT")
  const [sortBy, setSortBy] = useState("errorCount")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc")
  const [groupBy, setGroupBy] = useState("errorCategory")
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage] = useState(10)

  // Alert configuration state
  const [alertConfig, setAlertConfig] = useState({
    criticalThreshold: 20,
    highThreshold: 50,
    mediumThreshold: 100,
    frequency: "daily",
    recipients: ["ops@company.com", "eng@company.com"],
  })

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "Critical":
        return <Badge className="bg-red-100 text-red-800">Critical</Badge>
      case "High":
        return <Badge className="bg-orange-100 text-orange-800">High</Badge>
      case "Medium":
        return <Badge className="bg-yellow-100 text-yellow-800">Medium</Badge>
      case "Low":
        return <Badge className="bg-blue-100 text-blue-800">Low</Badge>
      default:
        return <Badge variant="secondary">{severity}</Badge>
    }
  }

  const filteredData = errorData.filter((item) => {
    const matchesSearch =
      searchTerm === "" ||
      item.errorCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.errorMessage.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.merchant.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesDate = dateFilter === "" || item.date.includes(dateFilter)
    const matchesMerchant = merchantFilter === "" || item.merchant === merchantFilter
    const matchesSeverity = severityFilter === "" || item.severity === severityFilter
    const matchesDevice = deviceFilter === "" || item.deviceType === deviceFilter
    const matchesSdk = sdkVersionFilter === "" || item.sdkVersion === sdkVersionFilter
    const matchesOs = osFilter === "" || item.osType === osFilter
    const matchesErrorCode = errorCodeFilter === "" || item.errorCode.includes(errorCodeFilter)

    return (
      matchesSearch &&
      matchesDate &&
      matchesMerchant &&
      matchesSeverity &&
      matchesDevice &&
      matchesSdk &&
      matchesOs &&
      matchesErrorCode
    )
  })

  const sortedData = [...filteredData].sort((a, b) => {
    let aValue: any = a[sortBy as keyof typeof a]
    let bValue: any = b[sortBy as keyof typeof b]

    if (sortBy === "errorCount") {
      aValue = Number(aValue)
      bValue = Number(bValue)
    }

    if (sortOrder === "asc") {
      return aValue > bValue ? 1 : -1
    } else {
      return aValue < bValue ? 1 : -1
    }
  })

  const paginatedData = sortedData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  const totalPages = Math.ceil(sortedData.length / itemsPerPage)

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(column)
      setSortOrder("desc")
    }
  }

  const handleDownload = () => {
    // Mock CSV download functionality
    const csvContent = [
      [
        "Date",
        "Merchant",
        "Error Code",
        "Error Category",
        "Severity",
        "Error Count",
        "Device Type",
        "SDK Version",
        "OS Type",
        "Error Message",
        "Description",
      ],
      ...filteredData.map((item) => [
        item.date,
        item.merchant,
        item.errorCode,
        item.errorCategory,
        item.severity,
        item.errorCount.toString(),
        item.deviceType,
        item.sdkVersion,
        item.osType,
        item.errorMessage,
        item.description,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `error-report-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Errors</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">236</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Critical Errors</CardTitle>
              <AlertTriangle className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">35</div>
              <p className="text-xs text-muted-foreground">Requires immediate attention</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Affected Merchants</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">Active merchants</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Error Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2.4%</div>
              <p className="text-xs text-muted-foreground">+0.3% from last week</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="errors" className="space-y-4">
          <TabsList>
            <TabsTrigger value="errors">Error Monitoring</TabsTrigger>
            <TabsTrigger value="alerts">Alert Configuration</TabsTrigger>
          </TabsList>

          <TabsContent value="errors" className="space-y-4">
            {/* Filters and Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Filters & Controls</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search errors..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                  <Select value={dateFilter} onValueChange={setDateFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Date" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2024-01-15">2024-01-15</SelectItem>
                      <SelectItem value="2024-01-14">2024-01-14</SelectItem>
                      <SelectItem value="2024-01-13">2024-01-13</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={merchantFilter} onValueChange={setMerchantFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Merchant" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ShopApp">ShopApp</SelectItem>
                      <SelectItem value="FoodDelivery">FoodDelivery</SelectItem>
                      <SelectItem value="RideShare">RideShare</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={severityFilter} onValueChange={setSeverityFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Severity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Critical">Critical</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={deviceFilter} onValueChange={setDeviceFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Device" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Mobile">Mobile</SelectItem>
                      <SelectItem value="Web">Web</SelectItem>
                      <SelectItem value="Desktop">Desktop</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={osFilter} onValueChange={setOsFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="OS Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Android">Android</SelectItem>
                      <SelectItem value="iOS">iOS</SelectItem>
                      <SelectItem value="Web">Web</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center space-x-2">
                    <Select value={groupBy} onValueChange={setGroupBy}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Group by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="errorCategory">Error Category</SelectItem>
                        <SelectItem value="errorCode">Error Code</SelectItem>
                        <SelectItem value="merchant">Merchant</SelectItem>
                        <SelectItem value="severity">Severity</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" onClick={handleDownload}>
                      <Download className="h-4 w-4 mr-2" />
                      Download CSV
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Error Table */}
            <Card>
              <CardHeader>
                <CardTitle>Error Details</CardTitle>
                <CardDescription>
                  Showing {paginatedData.length} of {filteredData.length} errors
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => handleSort("date")}>
                          <div className="flex items-center">
                            Date
                            {sortBy === "date" &&
                              (sortOrder === "asc" ? (
                                <ChevronUp className="ml-1 h-4 w-4" />
                              ) : (
                                <ChevronDown className="ml-1 h-4 w-4" />
                              ))}
                          </div>
                        </TableHead>
                        <TableHead>Merchant</TableHead>
                        <TableHead>
                          <div className="flex items-center">
                            Error Code
                            <Tooltip>
                              <TooltipTrigger>
                                <Info className="ml-1 h-3 w-3 text-muted-foreground" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Hover over error codes for descriptions</p>
                              </TooltipContent>
                            </Tooltip>
                          </div>
                        </TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => handleSort("severity")}>
                          <div className="flex items-center">
                            Severity
                            {sortBy === "severity" &&
                              (sortOrder === "asc" ? (
                                <ChevronUp className="ml-1 h-4 w-4" />
                              ) : (
                                <ChevronDown className="ml-1 h-4 w-4" />
                              ))}
                          </div>
                        </TableHead>
                        <TableHead
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => handleSort("errorCount")}
                        >
                          <div className="flex items-center">
                            Error Count
                            {sortBy === "errorCount" &&
                              (sortOrder === "asc" ? (
                                <ChevronUp className="ml-1 h-4 w-4" />
                              ) : (
                                <ChevronDown className="ml-1 h-4 w-4" />
                              ))}
                          </div>
                        </TableHead>
                        <TableHead>Device</TableHead>
                        <TableHead>SDK Version</TableHead>
                        <TableHead>OS</TableHead>
                        <TableHead>Error Message</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedData.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>{item.date}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{item.merchant}</Badge>
                          </TableCell>
                          <TableCell>
                            <Tooltip>
                              <TooltipTrigger>
                                <code className="text-sm bg-muted px-1 py-0.5 rounded cursor-help">
                                  {item.errorCode}
                                </code>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="max-w-xs">{item.description}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">{item.errorCategory}</Badge>
                          </TableCell>
                          <TableCell>{getSeverityBadge(item.severity)}</TableCell>
                          <TableCell className="font-medium text-red-600">{item.errorCount}</TableCell>
                          <TableCell>{item.deviceType}</TableCell>
                          <TableCell className="font-mono text-sm">{item.sdkVersion}</TableCell>
                          <TableCell>{item.osType}</TableCell>
                          <TableCell className="max-w-xs truncate" title={item.errorMessage}>
                            {item.errorMessage}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between mt-4">
                    <div className="text-sm text-muted-foreground">
                      Page {currentPage} of {totalPages}
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                        disabled={currentPage === 1}
                      >
                        Previous
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                        disabled={currentPage === totalPages}
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Alert Configuration</CardTitle>
                <CardDescription>
                  Configure email alerts based on error count thresholds per severity level
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Error Thresholds</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="critical">Critical Errors</Label>
                        <Input
                          id="critical"
                          type="number"
                          value={alertConfig.criticalThreshold}
                          onChange={(e) =>
                            setAlertConfig({ ...alertConfig, criticalThreshold: Number(e.target.value) })
                          }
                          className="w-20"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="high">High Severity Errors</Label>
                        <Input
                          id="high"
                          type="number"
                          value={alertConfig.highThreshold}
                          onChange={(e) => setAlertConfig({ ...alertConfig, highThreshold: Number(e.target.value) })}
                          className="w-20"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="medium">Medium Severity Errors</Label>
                        <Input
                          id="medium"
                          type="number"
                          value={alertConfig.mediumThreshold}
                          onChange={(e) => setAlertConfig({ ...alertConfig, mediumThreshold: Number(e.target.value) })}
                          className="w-20"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Alert Settings</h3>
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="frequency">Alert Frequency</Label>
                        <Select
                          value={alertConfig.frequency}
                          onValueChange={(value) => setAlertConfig({ ...alertConfig, frequency: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Recipients</Label>
                        <div className="space-y-2 mt-2">
                          {alertConfig.recipients.map((email, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <Checkbox checked={true} />
                              <span className="text-sm">{email}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button>
                    <Mail className="h-4 w-4 mr-2" />
                    Save Alert Configuration
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </TooltipProvider>
  )
}
