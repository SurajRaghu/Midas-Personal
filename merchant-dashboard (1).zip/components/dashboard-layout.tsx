import type React from "react"
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { AppSidebar } from "./app-sidebar"
import { Button } from "@/components/ui/button"
import { RefreshCw, Download } from "lucide-react"

interface DashboardLayoutProps {
  children: React.ReactNode
  title: string
  showActions?: boolean
  activeView?: string
  onNavigate?: (view: string) => void
}

export function DashboardLayout({
  children,
  title,
  showActions = true,
  activeView = "dashboard",
  onNavigate,
}: DashboardLayoutProps) {
  return (
    <SidebarProvider>
      <AppSidebar activeItem={activeView} onNavigate={onNavigate} />
      <div className="flex-1 flex flex-col min-h-screen">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold">{title}</h1>
          </div>
          {showActions && (
            <div className="ml-auto flex items-center gap-2">
              <Button variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          )}
        </header>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </SidebarProvider>
  )
}
